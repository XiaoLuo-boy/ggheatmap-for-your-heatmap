devtools::install_github("XiaoLuo-boy/ggheatmap")
install.packages("ggheatmap")
library(dplyr)
library(tibble)
library(Seurat)
library(patchwork)

#单细胞分析标准化流程：
#读入数据——质控——标准化——聚类——注释
pbmc.data <- Read10X(data.dir = "./filtered_gene_bc_matrices/hg19/")
pbmc <- CreateSeuratObject(counts = pbmc.data, project = "pbmc3k", min.cells = 3, min.features = 200)
pbmc
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")
pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)
pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 2000)
all.genes <- rownames(pbmc)
pbmc <- ScaleData(pbmc, features = all.genes)
pbmc <- RunPCA(pbmc, features = VariableFeatures(object = pbmc))
pbmc <- FindNeighbors(pbmc, dims = 1:10)
pbmc <- FindClusters(pbmc, resolution = 0.5)
pbmc <- RunUMAP(pbmc, dims = 1:10)
pbmc <- RunTSNE(pbmc,dims = 1:10)
new.cluster.ids <- c("Naive CD4 T", "CD14+ Mono", "Memory CD4 T", "B", "CD8 T", "FCGR3A+ Mono",
                     "NK", "DC", "Platelet")
names(new.cluster.ids) <- levels(pbmc)
pbmc <- RenameIdents(pbmc, new.cluster.ids)
DimPlot(pbmc, reduction = "umap", label = TRUE, pt.size = 0.5) + NoLegend()
DimPlot(pbmc, reduction = "tsne", label = TRUE, pt.size = 0.5) + NoLegend()

#筛选出排名前4的基因
head(pbmc@meta.data)
pbmc.markers <- FindAllMarkers(pbmc, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
top4 <- pbmc.markers %>%
  group_by(cluster) %>%
  top_n(n = 4, wt = avg_log2FC)





#使用ggheatmap绘制热图
scaledata <- pbmc@assays$RNA@scale.data[unique(top4$gene),]
#ggheatmap(scaledata,text_show_cols = F,show_cluster_cols = F,show_cluster_rows = F)
library(ggheatmap)
scaledata[1:4,1:4]
scaledata[scaledata>2.5]=2.5 #注意这里的数据处理，模仿DoHeatmap
scaledata[scaledata<-2.5]=-2.5 
col_level <- Idents(pbmc)
head(col_level)
head(names(col_level))
head(sort(col_level))
col_level <- sort(col_level)
col_metadata <- as.data.frame(col_level)
colnames(col_metadata) <- "Celltype"
head(col_metadata)
col <- ggsci::pal_d3()(9)
names(col) <- unique(col_level)
col <- list(Celltype=col)
p <- ggheatmap(scaledata,cluster_rows = F,cluster_cols = F,
               text_show_cols = F,
               show_cluster_cols = F,show_cluster_rows = F,
               levels_cols = names(col_level),
               levels_rows = rev(rownames(scaledata)),
               annotation_cols = col_metadata,
               annotation_color = col
          )
p
p%>%ggheatmap_theme(2,theme = list(theme(axis.text.y = element_blank())))
#准备注释数据
row_metadata <- as.data.frame(top4[,c("cluster","gene")])
row_metadata$celltype <- "celltype"
row_metadata$gene <- factor(row_metadata$gene,levels = row_metadata$gene)
gene <- as.character(row_metadata$gene)
label <- c("Naive CD4 T",NA,gene[1:4],
           "CD14+ Mono",NA,gene[5:8],
           "Memory CD4 T",NA,gene[9:12],
           "B",NA,gene[13:16],
           "CD8 T",NA,gene[17:20],
           "FCGR3A+ Mono",NA,gene[21:24],
           "NK",NA,gene[25:28],
           "DC",NA,gene[29:32],
           "Platelet",NA,gene[33:36]
)
p1<- ggplot(row_metadata,mapping = aes(x=rev(gene),y=celltype,fill=cluster))+
  geom_tile()+
  scale_fill_manual(values =ggsci::pal_d3()(9))+
  theme(legend.position = "none",
        axis.title = element_blank(),axis.text = element_blank(),
        axis.ticks = element_blank(),panel.background = element_blank())+
  coord_flip()+
  annotate("text",
           x=rev(rep(seq(1.3,36,4/3),each=2)),
           y=rep(c(0.8,1.3),times=27),
           label=label,
           size=rep(c(3.5,NA,3,3,3,3),9),
           fontface=rep(c("bold",NA,"italic","italic","italic","italic"),9))

p %>%aplot::insert_left(p1,0.5)



#比较用DoHeatmap绘制结果
p0 <- DoHeatmap(pbmc, features = top4$gene,size = 0,group.bar.height = 0) + NoLegend()
p0%>%aplot::insert_right(p1,0.5)
